import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, ArrowRight, Tag, Search } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface BlogProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
}

const Blog: React.FC<BlogProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).blog;
  const [activeCategory, setActiveCategory] = useState(t.categories[0]);

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Blog Hero */}
      <section className="bg-white dark:bg-gray-800 py-16 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            {t.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-300"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>
      </section>

      {/* Filter & Search Bar */}
      <section className="py-8 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-wrap justify-center gap-3">
            {t.categories.map((cat: string) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-brand-600 text-white shadow-lg'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-900/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-64">
             <Search className="absolute left-3 top-3 text-gray-400" size={18} />
             <input 
               type="text" 
               placeholder={language === 'EN' ? 'Search insights...' : 'Buscar perspectivas...'}
               className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 outline-none focus:ring-2 focus:ring-brand-200 dark:text-white"
             />
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {t.posts.filter((p: any) => activeCategory === t.categories[0] || p.category === activeCategory).map((post: any, idx: number) => (
            <motion.article 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 group hover:shadow-xl transition-all"
            >
              <div className="h-48 bg-gradient-to-br from-brand-500 to-blue-500 relative">
                 <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                   {post.category}
                 </div>
              </div>
              <div className="p-8">
                <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400 mb-4">
                  <span className="flex items-center gap-1"><Calendar size={14} /> {post.date}</span>
                  <span className="flex items-center gap-1"><User size={14} /> Gabriel Team</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-2">
                  {post.excerpt}
                </p>
                <button className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-bold hover:gap-3 transition-all">
                  {t.readMore} <ArrowRight size={18} />
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 bg-brand-600 text-white text-center">
        <div className="max-w-2xl mx-auto px-4">
          <Tag className="mx-auto mb-6 opacity-50" size={48} />
          <h2 className="text-3xl font-bold mb-4">
            {language === 'EN' ? 'Stay Ahead of the Growth Curve' : 'Mantente a la vanguardia de la curva de crecimiento'}
          </h2>
          <p className="text-brand-100 mb-8">
            {language === 'EN' ? 'Weekly operational scaling strategies delivered to your inbox.' : 'Estrategias semanales de escalamiento operativo entregadas a tu bandeja de entrada.'}
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
             <input 
               type="email" 
               placeholder={language === 'EN' ? 'Work email' : 'Correo de trabajo'} 
               className="flex-1 px-6 py-4 rounded-2xl text-gray-900 outline-none" 
             />
             <button className="bg-white text-brand-700 font-bold px-8 py-4 rounded-2xl hover:bg-gray-100 transition-all">
                {language === 'EN' ? 'Subscribe' : 'Suscribirse'}
             </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;