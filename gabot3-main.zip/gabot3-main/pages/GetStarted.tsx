import React, { useState } from 'react';
import { Rocket, Check, User, Briefcase, Mail, Phone, ArrowRight, Home } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface GetStartedProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
}

const GetStarted: React.FC<GetStartedProps> = ({ onNavigate, language }) => {
  const [step, setStep] = useState(1);
  const t = translations[language].auth;
  const isEn = language === 'EN';

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col pt-20 transition-colors relative">
      {/* Back to Home Button */}
      <button 
        onClick={() => onNavigate('home')}
        className="absolute top-6 left-6 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all shadow-sm group"
      >
        <Home size={18} className="group-hover:scale-110 transition-transform" />
        <span className="font-bold text-sm tracking-wide">{isEn ? 'Back to Home' : 'Volver al Inicio'}</span>
      </button>

      <div className="flex-grow flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-5xl overflow-hidden flex flex-col lg:flex-row border border-gray-100 dark:border-gray-700">
          
          {/* Sidebar Info */}
          <div className="lg:w-1/3 bg-brand-600 p-8 text-white flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-8">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center text-white">
                   <Rocket size={20} />
                </div>
                <span className="text-2xl font-bold tracking-tight">Gabriel</span>
              </div>
              <h2 className="text-3xl font-bold mb-4">{t.trialTitle}</h2>
              <p className="text-brand-100 mb-8">{t.trialSubtitle}</p>
              
              <ul className="space-y-4">
                {t.perks.map((item: string, i: number) => (
                  <li key={i} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                      <Check size={14} />
                    </div>
                    <span className="text-sm font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mt-12 pt-8 border-t border-brand-500">
              <div className="flex items-center gap-4">
                 <div className="flex -space-x-2">
                   {[1,2,3].map(i => (
                     <div key={i} className="w-8 h-8 rounded-full bg-brand-300 border-2 border-brand-600"></div>
                   ))}
                 </div>
                 <div className="text-xs text-brand-100">
                   <span className="font-bold text-white">4.9/5</span> {t.rating}
                 </div>
              </div>
            </div>
          </div>

          {/* Form Section */}
          <div className="lg:w-2/3 p-8 md:p-12">
            <div className="mb-8 flex justify-between items-center">
               <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t.getStartedTitle}</h1>
               <div className="text-sm text-gray-500 dark:text-gray-400">
                  {t.step} {step} of 2
               </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-gray-100 dark:bg-gray-700 rounded-full mb-10">
               <div 
                 className="h-full bg-brand-600 rounded-full transition-all duration-300"
                 style={{ width: step === 1 ? '50%' : '100%' }}
               ></div>
            </div>

            <form className="space-y-6">
              {step === 1 ? (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                       <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.firstName}</label>
                       <div className="relative">
                          <User size={18} className="absolute left-3 top-3.5 text-gray-400" />
                          <input type="text" className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none" placeholder="Jane" />
                       </div>
                    </div>
                    <div>
                       <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.lastName}</label>
                       <div className="relative">
                          <User size={18} className="absolute left-3 top-3.5 text-gray-400" />
                          <input type="text" className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none" placeholder="Doe" />
                       </div>
                    </div>
                  </div>
                  <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.workEmail}</label>
                     <div className="relative">
                        <Mail size={18} className="absolute left-3 top-3.5 text-gray-400" />
                        <input type="email" className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none" placeholder="jane@company.com" />
                     </div>
                  </div>
                  <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.phone}</label>
                     <div className="relative">
                        <Phone size={18} className="absolute left-3 top-3.5 text-gray-400" />
                        <input type="tel" className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none" placeholder="+1 (555) 000-0000" />
                     </div>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => setStep(2)}
                    className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2 mt-4"
                  >
                    {t.continue} <ArrowRight size={18} />
                  </button>
                </div>
              ) : (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                  <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.companyName}</label>
                     <div className="relative">
                        <Briefcase size={18} className="absolute left-3 top-3.5 text-gray-400" />
                        <input type="text" className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none" placeholder="Acme Inc." />
                     </div>
                  </div>
                  <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.companySize}</label>
                     <select className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none bg-white">
                        <option>1-10 employees</option>
                        <option>11-50 employees</option>
                        <option>51-200 employees</option>
                        <option>201-500 employees</option>
                        <option>500+ employees</option>
                     </select>
                  </div>
                  <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.primaryInterest}</label>
                     <select className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none bg-white">
                        <option>Logistics Management</option>
                        <option>IT Support</option>
                        <option>C-Level Admin Support</option>
                        <option>Customer Relations</option>
                        <option>Other</option>
                     </select>
                  </div>
                  
                  <div className="flex gap-4 mt-8">
                    <button 
                      type="button" 
                      onClick={() => setStep(1)}
                      className="w-1/3 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-bold py-3 rounded-lg transition-colors"
                    >
                      {t.back}
                    </button>
                    <button 
                      type="button" 
                      className="w-2/3 bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-lg transition-colors shadow-lg"
                    >
                      {t.createAccount}
                    </button>
                  </div>
                </div>
              )}
            </form>

            <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                {t.alreadyHave}{' '}
                <button 
                  onClick={() => onNavigate('signin')}
                  className="text-brand-600 font-semibold hover:underline"
                >
                  {translations[language].nav.signin}
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetStarted;