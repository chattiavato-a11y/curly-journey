import React from 'react';
import { Heart, TrendingUp, Clock, Briefcase, Smile, Award } from 'lucide-react';
import { Page, Language } from '../types';
import { motion } from 'framer-motion';
import { translations } from '../translations';

interface CareersProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const Careers: React.FC<CareersProps> = ({ onNavigate, language }) => {
  const t = translations[language].careers;

  const benefits = [
    { icon: Smile, title: 'Great Culture', desc: 'Work with talented professionals in a collaborative environment.' },
    { icon: TrendingUp, title: 'Career Growth', desc: 'Access continuous learning and clear paths for advancement.' },
    { icon: Clock, title: 'Work-Life Balance', desc: 'Enjoy flexible schedules and remote work options.' },
  ];
  
  const perks = [
      'Competitive salary and performance bonuses',
      'Comprehensive health insurance',
      'Flexible work arrangements',
      'Professional development opportunities',
      'Paid time off and holidays',
      '401(k) retirement plan',
      'Remote work options',
      'Collaborative team environment'
  ];

  const positions = [
    { title: 'Senior Logistics Coordinator', dept: 'Logistics', type: 'Full-time', loc: 'Remote' },
    { title: 'IT Support Specialist', dept: 'IT Support', type: 'Full-time', loc: 'Hybrid' },
    { title: 'Executive Assistant', dept: 'Admin Support', type: 'Full-time', loc: 'Remote' },
    { title: 'Customer Relations Manager', dept: 'Customer Relations', type: 'Full-time', loc: 'Remote' },
  ];

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Careers Hero */}
      <section className="bg-white dark:bg-gray-800 py-16 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            {t.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-300"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>
      </section>

      {/* Why Work Here */}
      <section className="py-20">
         <div className="max-w-7xl mx-auto px-4 text-center">
           <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-16">{t.whyTitle}</h2>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {benefits.map((b, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700"
                >
                   <div className="w-14 h-14 mx-auto bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full flex items-center justify-center mb-6">
                     <b.icon size={24} />
                   </div>
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{b.title}</h3>
                   <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{b.desc}</p>
                </motion.div>
              ))}
           </div>
         </div>
      </section>

      {/* Benefits List */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-5xl mx-auto px-4">
           <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-12 text-center">{t.perksTitle}</h2>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
              {perks.map((perk, idx) => (
                <div key={idx} className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-700 rounded-xl transition-transform hover:translate-x-2">
                   <div className="w-2 h-2 rounded-full bg-brand-500"></div>
                   <span className="text-gray-700 dark:text-gray-200 font-medium">{perk}</span>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-4xl mx-auto px-4">
           <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-12 text-center">{t.positionsTitle}</h2>
           <div className="space-y-4">
             {positions.map((pos, idx) => (
               <motion.div 
                 key={idx}
                 initial={{ opacity: 0, y: 10 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
               >
                 <div>
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-brand-600 transition-colors">{pos.title}</h3>
                   <p className="text-brand-600 dark:text-brand-400 font-medium mb-1">{pos.dept}</p>
                   <div className="flex gap-4 text-sm text-gray-500 dark:text-gray-400">
                     <span className="flex items-center gap-1"><Briefcase size={14} /> {pos.type}</span>
                     <span className="flex items-center gap-1"><Award size={14} /> {pos.loc}</span>
                   </div>
                 </div>
                 <button className="bg-brand-600 hover:bg-brand-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-md hover:shadow-brand-500/20 shrink-0">
                   {t.apply}
                 </button>
               </motion.div>
             ))}
           </div>
        </div>
      </section>

      {/* General App */}
      <section className="py-20 bg-gradient-to-r from-brand-600 to-purple-600 text-center text-white relative overflow-hidden">
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <h2 className="text-3xl font-bold mb-4">{t.generalTitle}</h2>
          <button className="bg-white text-brand-700 hover:bg-gray-100 px-10 py-4 rounded-full font-bold text-lg transition-all shadow-xl transform hover:scale-105">
            {t.generalBtn}
          </button>
        </div>
        <div className="absolute inset-0 bg-white opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, currentColor 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
      </section>
    </div>
  );
};

export default Careers;