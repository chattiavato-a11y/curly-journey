import React, { useEffect, useRef, useState } from 'react';
import { Truck, Monitor, UserCheck, HeartHandshake, ArrowRight, Shield, X, Check, BarChart, CreditCard } from 'lucide-react';
import { Page, Language } from '../types';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { translations } from '../translations';

// Define the props interface for the Services component to fix the "Cannot find name 'ServicesProps'" error.
interface ServicesProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  targetSection?: string;
  language: Language;
  onSetPlan: (planId: string) => void;
}

interface ServiceData {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  features: string[];
  link: Page;
  color: string;
  summary: string;
  planId: string;
  details: {
    extendedDescription: string;
    benefits: string[];
    caseStudy: {
      company: string;
      result: string;
      quote: string;
    };
    stats: { label: string; value: string }[];
  };
}

interface ServiceSectionProps {
  section: ServiceData;
  idx: number;
  onShowDetails: (section: ServiceData) => void;
  onNavigate: (page: Page, sectionId?: string) => void;
  onSetPlan: (planId: string) => void;
  language: Language;
}

const springSummerPalette = [
  '#FF6AD5', '#C774E8', '#94D0FF', '#1DE4BD', '#61FF7E', '#FF71CE', '#05FFA1', '#01CDFE', '#B967FF', '#4ade80', '#22d3ee'
];

const royalPurples = ['#581c87', '#6b21a8', '#7e22ce', '#4c1d95', '#5b21b6', '#6d28d9', '#312e81', '#3730a3', '#4338ca'];

const TechCard: React.FC<{ tech: string; idx: number }> = ({ tech, idx }) => {
  const [hoverColor, setHoverColor] = useState<string | null>(null);
  const handleInteraction = () => setHoverColor(springSummerPalette[Math.floor(Math.random() * springSummerPalette.length)]);
  const clearInteraction = () => setHoverColor(null);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: idx * 0.05, duration: 0.3 }}
      onMouseEnter={handleInteraction}
      onMouseDown={handleInteraction}
      onMouseLeave={clearInteraction}
      style={{
        borderColor: hoverColor ? hoverColor : undefined,
        color: hoverColor ? hoverColor : undefined,
        boxShadow: hoverColor ? `0 0 20px ${hoverColor}33` : undefined,
      }}
      className="p-6 rounded-xl bg-gray-50 dark:bg-gray-700/50 text-gray-700 dark:text-gray-200 font-medium border border-gray-100 dark:border-gray-600 cursor-pointer transition-all duration-300 text-center"
    >
      {tech}
    </motion.div>
  );
};

const ServiceModal = ({ section, onClose, onNavigate, onSetPlan, language }: { section: ServiceData; onClose: () => void; onNavigate: (page: Page) => void, onSetPlan: (planId: string) => void, language: Language }) => {
  if (!section) return null;
  const t = (translations[language] || translations['EN']).services;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md"
      />
      <motion.div
        layoutId={`card-${section.id}`}
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative bg-white dark:bg-gray-800 w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
      >
        <div className={`p-10 ${section.color.split(' ')[0]} bg-opacity-30 relative overflow-hidden shrink-0`}>
           <button onClick={onClose} className="absolute top-6 right-6 p-2.5 bg-white/20 hover:bg-white/40 rounded-full text-gray-800 dark:text-white transition-all z-20">
             <X size={24} />
           </button>
           <div className="flex items-center gap-8 relative z-10">
              <div className="w-24 h-24 bg-white dark:bg-gray-900 rounded-2xl flex items-center justify-center shadow-xl text-brand-600 dark:text-brand-400">
                <section.icon size={48} />
              </div>
              <div>
                <h3 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">{section.title}</h3>
                <p className="text-xl opacity-90 font-medium text-brand-800 dark:text-brand-200">{t.enterprise}</p>
              </div>
           </div>
           <div className="absolute -top-24 -right-24 w-80 h-80 bg-current opacity-10 rounded-full blur-[100px]"></div>
        </div>

        <div className="p-10 overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div className="space-y-10">
              <div>
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                  <Shield className="text-brand-500" size={24} /> Service Depth
                </h4>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-lg mb-8">
                  {section.details.extendedDescription}
                </p>
              </div>
              
              <div>
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Execution Benefits</h4>
                <ul className="space-y-4">
                  {section.details.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start gap-3 text-gray-600 dark:text-gray-300 text-lg">
                      <Check className="text-green-500 mt-1.5 shrink-0" size={20} />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="space-y-10">
               <div className="grid grid-cols-2 gap-6">
                  {section.details.stats.map((stat, i) => (
                    <div key={i} className="bg-gray-50 dark:bg-gray-700/40 p-6 rounded-2xl text-center border border-gray-100 dark:border-gray-600 shadow-sm">
                      <div className="text-3xl font-bold text-brand-600 dark:text-brand-400 mb-1">{stat.value}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-[0.15em] font-bold">{stat.label}</div>
                    </div>
                  ))}
               </div>

               <div className="bg-brand-50 dark:bg-brand-900/10 p-8 rounded-3xl border border-brand-100 dark:border-brand-800 shadow-inner">
                 <h4 className="text-sm font-bold text-brand-700 dark:text-brand-300 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                   <BarChart size={20} /> Client Case Study
                 </h4>
                 <div className="mb-6">
                   <div className="text-3xl font-bold text-gray-900 dark:text-white mb-1">{section.details.caseStudy.result}</div>
                   <div className="text-sm text-gray-500 dark:text-gray-400 font-medium">Metric recorded for {section.details.caseStudy.company}</div>
                 </div>
                 <p className="italic text-gray-600 dark:text-gray-300 text-lg border-l-4 border-brand-400 pl-6 py-1">
                   "{section.details.caseStudy.quote}"
                 </p>
               </div>
            </div>
          </div>
        </div>

        <div className="p-8 border-t border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 flex justify-end items-center gap-6 shrink-0">
           <button onClick={onClose} className="px-8 py-4 rounded-2xl font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all">
             Dismiss
           </button>
           <button 
             onClick={() => { onSetPlan(section.planId); onClose(); onNavigate('checkout'); }}
             className="px-10 py-4 rounded-2xl font-bold text-white bg-brand-600 hover:bg-brand-700 transition-all shadow-xl shadow-brand-500/30 flex items-center gap-3 transform hover:-translate-y-0.5 active:scale-95"
           >
             Subscribe Now <ArrowRight size={22} />
           </button>
        </div>
      </motion.div>
    </div>
  );
};

const ServiceSection: React.FC<ServiceSectionProps> = ({ section, idx, onShowDetails, onNavigate, onSetPlan, language }) => {
  const ref = useRef<HTMLElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [hoverColor, setHoverColor] = useState('');
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const t = (translations[language] || translations['EN']).services;
  
  const yCard = useTransform(scrollYProgress, [0, 1], [40, -40]);
  const yIcon = useTransform(scrollYProgress, [0, 1], [-20, 20]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);

  const handleMouseEnter = () => {
    setHoverColor(royalPurples[Math.floor(Math.random() * royalPurples.length)]);
    setIsHovered(true);
  };

  return (
    <section ref={ref} id={section.id} className="py-24 bg-white dark:bg-gray-800 odd:bg-gray-50 dark:odd:bg-gray-900 transition-colors duration-300 overflow-hidden">
       <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12">
          <div className={`flex flex-col md:flex-row items-center gap-16 ${idx % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
             <motion.div className="flex-1 z-10" style={{ opacity }}>
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-8 ${section.color} shadow-sm`}>
                  <section.icon size={32} />
                </div>
                <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6 tracking-tight">{section.title}</h2>
                <p className="text-xl text-gray-600 dark:text-gray-300 mb-10 leading-relaxed font-light">
                  {section.description}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 mb-10">
                  {section.features.map((feat: string, i: number) => (
                    <div key={i} className="flex items-center gap-3 text-base text-gray-700 dark:text-gray-200 font-semibold">
                      <Check className="text-brand-500" size={18} />
                      {feat}
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-4">
                  <button onClick={() => onShowDetails(section)} className="group inline-flex items-center gap-3 text-brand-600 dark:text-brand-400 font-black text-lg hover:text-brand-800 dark:hover:text-brand-200 transition-all">
                    {t.learnMore} <ArrowRight size={22} className="group-hover:translate-x-2 transition-transform" />
                  </button>
                  <button onClick={() => { onSetPlan(section.planId); onNavigate('checkout'); }} className="bg-brand-600 hover:bg-brand-700 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-brand-500/20 transition-all flex items-center gap-2 transform hover:scale-105 active:scale-95">
                    <CreditCard size={18} /> Subscribe
                  </button>
                </div>
             </motion.div>
             
             <div className="flex-1 w-full relative">
                <motion.div 
                  layoutId={`card-bg-${section.id}`}
                  style={{ 
                    y: yCard, 
                    backgroundColor: isHovered ? hoverColor : undefined,
                    scale: isHovered ? 1.05 : 1
                  }}
                  className="bg-white dark:bg-gray-700 rounded-[2.5rem] p-12 shadow-2xl border border-gray-100 dark:border-gray-600 relative overflow-hidden group transition-all duration-500 ease-out cursor-pointer h-full"
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={() => setIsHovered(false)}
                  onClick={() => onShowDetails(section)}
                >
                   <motion.div style={{ y: yIcon }} className={`absolute -bottom-10 -right-10 transition-all duration-500 ${isHovered ? 'opacity-10 scale-125 text-white' : 'opacity-5 text-black dark:text-white'}`}>
                      <section.icon size={300} className="currentColor" />
                   </motion.div>

                   <div className="relative z-10 h-full flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-4 mb-8">
                           <Shield className={`transition-colors duration-300 ${isHovered ? 'text-white' : 'text-green-500'}`} />
                           <span className={`text-xl font-bold tracking-tight transition-colors duration-300 ${isHovered ? 'text-white' : 'text-gray-900 dark:text-white'}`}>{t.enterprise}</span>
                        </div>
                        <div className="space-y-6">
                           <div className={`h-2.5 rounded-full w-3/4 transition-colors duration-300 ${isHovered ? 'bg-white/40' : 'bg-gray-100 dark:bg-gray-600'}`}></div>
                           <div className={`h-2.5 rounded-full w-full transition-colors duration-300 ${isHovered ? 'bg-white/40' : 'bg-gray-100 dark:bg-gray-600'}`}></div>
                           <div className={`h-2.5 rounded-full w-2/3 transition-colors duration-300 ${isHovered ? 'bg-white/40' : 'bg-gray-100 dark:bg-gray-600'}`}></div>
                        </div>
                      </div>

                      <div className="mt-12 flex gap-6">
                         <div className={`p-6 rounded-3xl flex-1 text-center transition-all duration-300 ${isHovered ? 'bg-white/10 text-white' : 'bg-gray-50 dark:bg-gray-600 shadow-sm'}`}>
                            <div className={`font-black text-3xl mb-1 transition-colors duration-300 ${isHovered ? 'text-white' : 'text-gray-900 dark:text-white'}`}>24/7</div>
                            <div className={`text-xs uppercase tracking-widest font-bold transition-colors duration-300 ${isHovered ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>L1 & L2</div>
                         </div>
                         <div className={`p-6 rounded-3xl flex-1 text-center transition-all duration-300 ${isHovered ? 'bg-white/10 text-white' : 'bg-gray-50 dark:bg-gray-600 shadow-sm'}`}>
                            <div className={`font-black text-3xl mb-1 transition-colors duration-300 ${isHovered ? 'text-white' : 'text-gray-900 dark:text-white'}`}>100%</div>
                            <div className={`text-xs uppercase tracking-widest font-bold transition-colors duration-300 ${isHovered ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>SLAs</div>
                         </div>
                      </div>
                   </div>
                </motion.div>
             </div>
          </div>
       </div>
    </section>
  );
};

const Services: React.FC<ServicesProps> = ({ onNavigate, targetSection, onSetPlan, language }) => {
  const [selectedService, setSelectedService] = useState<ServiceData | null>(null);
  const t = (translations[language] || translations['EN']).services;

  useEffect(() => {
    if (targetSection) {
      const element = document.getElementById(targetSection);
      if (element) setTimeout(() => element.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    }
  }, [targetSection]);

  const sections: ServiceData[] = [
    {
      id: 'logistics-section',
      title: t.list.logistics.title,
      description: t.list.logistics.desc,
      icon: Truck,
      features: language === 'EN' ? ['Fleet Dispatching', 'Route Optimization', 'Inventory Tracking', 'Driver Management'] : ['Despacho de Flotas', 'Optimización de Rutas', 'Seguimiento de Inventario', 'Gestión de Conductores'],
      link: 'logistics',
      planId: 'logistics',
      color: 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400',
      summary: language === 'EN' ? 'Drastically reduce delivery overhead via advanced mapping.' : 'Reduzca drásticamente los gastos de envío mediante el mapeo avanzado.',
      details: {
        extendedDescription: 'Our logistics management platform uses proprietary algorithms to calculate the most efficient routes, reducing fuel consumption by up to 20%.',
        benefits: ['Real-time GPS tracking', 'Automated maintenance scheduling', 'Fuel cost analytics'],
        caseStudy: { company: 'Global Retail Corp', result: '20% Reduction in OpEx', quote: 'Gabriel revolutionized our dispatch system. We handle 30% more volume.' },
        stats: [{ label: 'On-Time Rate', value: '99.8%' }, { label: 'Active Drivers', value: '5k+' }]
      }
    },
    {
      id: 'it-support-section',
      title: t.list.itsupport.title,
      description: t.list.itsupport.desc,
      icon: Monitor,
      features: language === 'EN' ? ['Help Desk Support', 'Network Troubleshooting', 'Hardware Config', 'Security Patches'] : ['Mesa de Ayuda', 'Solución de Redes', 'Configuración de Hardware', 'Seguridad'],
      link: 'itsupport',
      planId: 'itsupport_l1',
      color: 'bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400',
      summary: language === 'EN' ? 'Expert technical assistance to eliminate downtime.' : 'Asistencia técnica para eliminar tiempos de inactividad.',
      details: {
        extendedDescription: 'From password resets to network diagnostics, our professionals are ready 24/7. Proactive monitoring ensures stability.',
        benefits: ['24/7/365 Help Desk', 'Remote Support', 'Security Monitoring'],
        caseStudy: { company: 'FinTech Innovators', result: '99.99% Uptime', quote: 'The peace of mind knowing Gabriel is watching is invaluable.' },
        stats: [{ label: 'Avg Response', value: '< 2 min' }, { label: 'Resolved', value: '50k+' }]
      }
    },
    {
      id: 'admin-section',
      title: t.list.admin.title,
      description: t.list.admin.desc,
      icon: UserCheck,
      features: language === 'EN' ? ['Calendar Mgmt', 'Travel Coordination', 'Meeting Prep', 'Inbox Zero'] : ['Gestión de Calendario', 'Viajes', 'Reuniones', 'Bandeja Cero'],
      link: 'admin',
      planId: 'admin',
      color: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400',
      summary: language === 'EN' ? 'Recapture up to 15 hours of your work week.' : 'Recupere hasta 15 horas de su semana laboral.',
      details: {
        extendedDescription: 'Executive assistance beyond basic scheduling. Strategic planning for international itineraries.',
        benefits: ['Inbox Management', 'Board Prep', 'Confidential Handling'],
        caseStudy: { company: 'Nexus Holdings', result: '15+ Hours Saved', quote: 'My assistant anticipates needs before I even articulate them.' },
        stats: [{ label: 'Execs Supported', value: '200+' }, { label: 'Hours Saved', value: '10k+' }]
      }
    },
    {
      id: 'relations-section',
      title: t.list.relations.title,
      description: t.list.relations.desc,
      icon: HeartHandshake,
      features: language === 'EN' ? ['Inbound Support', 'Client Onboarding', 'Satisfaction Surveys', 'Conflict Resolution'] : ['Soporte de Entrada', 'Onboarding', 'Encuestas', 'Conflictos'],
      link: 'relations',
      planId: 'relations',
      color: 'bg-pink-50 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400',
      summary: language === 'EN' ? 'Human-centric customer care that builds loyalty.' : 'Atención centrada en el humano para generar lealtad.',
      details: {
        extendedDescription: 'Omnichannel support (voice, chat, email). Our agents embody your brand voice.',
        benefits: ['Omnichannel Support', 'CRM Integration', 'NPS Tracking'],
        caseStudy: { company: 'StreamLine SaaS', result: '45% Increase in NPS', quote: 'Customer churn dropped significantly within 3 months.' },
        stats: [{ label: 'CSAT Score', value: '4.9/5' }, { label: 'Languages', value: '12+' }]
      }
    }
  ];

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <AnimatePresence>
        {selectedService && (
          <ServiceModal section={selectedService} onClose={() => setSelectedService(null)} onNavigate={onNavigate} onSetPlan={onSetPlan} language={language} />
        )}
      </AnimatePresence>

      <section className="bg-white dark:bg-gray-800 py-24 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-8 tracking-tighter">{t.heroTitle}</h1>
            <p className="text-2xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto font-light leading-relaxed">
              {t.heroSubtitle}
            </p>
          </motion.div>
        </div>
      </section>

      <div className="py-12">
        {sections.map((section, idx) => (
          <ServiceSection key={idx} section={section} idx={idx} onShowDetails={setSelectedService} onNavigate={onNavigate} onSetPlan={onSetPlan} language={language} />
        ))}
      </div>

      <section className="py-32 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 text-center">
           <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
             <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6 tracking-tight">{t.techTitle}</h2>
             <p className="text-xl text-gray-600 dark:text-gray-300 mb-16 max-w-xl mx-auto font-light">{t.techSubtitle}</p>
           </motion.div>
           <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
             {['Windows Server', 'Linux/Unix', 'Microsoft 365', 'Azure/AWS', 'VMware', 'Cisco Networking', 'Active Directory', 'And More'].map((tech, idx) => (
               <TechCard key={idx} tech={tech} idx={idx} />
             ))}
           </div>
        </div>
      </section>

      <section className="py-24 bg-gradient-to-r from-brand-700 to-brand-500 text-center text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '32px 32px'}}></div>
        <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="relative z-10">
          <h2 className="text-4xl font-bold mb-8 tracking-tight">{t.ctaTitle}</h2>
          <button onClick={() => onNavigate('contact')} className="bg-white text-brand-700 px-12 py-4 rounded-2xl font-black text-lg hover:bg-gray-100 transition-all shadow-2xl transform hover:-translate-y-1 active:scale-95">
            {t.ctaBtn}
          </button>
        </motion.div>
      </section>
    </div>
  );
};

export default Services;