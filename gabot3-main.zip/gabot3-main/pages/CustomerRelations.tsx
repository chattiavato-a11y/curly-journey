import React from 'react';
import { HeartHandshake, MessageCircle, Users, Star, RefreshCw, Globe } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface CustomerRelationsProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const CustomerRelations: React.FC<CustomerRelationsProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).services.pages.relations;
  const isEn = language === 'EN';

  const features = [
    { icon: MessageCircle, title: isEn ? 'Inbound Support' : 'Soporte de Entrada', desc: isEn ? 'Responsive handling of customer inquiries via phone, email, and chat.' : 'Atención receptiva de consultas de clientes a través de teléfono, correo y chat.' },
    { icon: Users, title: isEn ? 'Client Onboarding' : 'Incorporación de Clientes', desc: isEn ? 'Guiding new clients through your services for a smooth start.' : 'Guiar a los nuevos clientes a través de sus servicios para un comienzo sin problemas.' },
    { icon: Star, title: isEn ? 'Satisfaction Surveys' : 'Encuestas de Satisfacción', desc: isEn ? 'Collecting and analyzing feedback to improve customer experience.' : 'Recopilar y analizar comentarios para mejorar la experiencia del cliente.' },
    { icon: RefreshCw, title: isEn ? 'Retention Strategies' : 'Estrategias de Retención', desc: isEn ? 'Proactive outreach to reduce churn and increase lifetime value.' : 'Alcance proactivo para reducir la deserción y aumentar el valor de vida del cliente.' },
    { icon: HeartHandshake, title: isEn ? 'Conflict Resolution' : 'Resolución de Conflictos', desc: isEn ? 'Turning difficult situations into opportunities for loyalty.' : 'Convertir situaciones difíciles en oportunidades de lealtad.' },
    { icon: Globe, title: isEn ? 'Multilingual Support' : 'Soporte Multilingüe', desc: isEn ? 'Serving your global customer base in their native languages.' : 'Atender a su base de clientes global en sus idiomas nativos.' },
  ];

  return (
    <div className="pt-20 min-h-screen bg-white dark:bg-gray-900 transition-colors">
      {/* Hero */}
      <section className="bg-pink-50 dark:bg-pink-900/10 py-20 text-center transition-colors">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            {t.title}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            {t.subtitle}
          </p>
        </div>
      </section>

      {/* Main Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feat, idx) => (
                <div key={idx} className="p-8 border border-gray-100 dark:border-gray-800 rounded-xl hover:shadow-lg transition-all bg-white dark:bg-gray-800">
                   <div className="w-12 h-12 bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 rounded-lg flex items-center justify-center mb-6">
                      <feat.icon size={24} />
                   </div>
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{feat.title}</h3>
                   <p className="text-gray-600 dark:text-gray-400">{feat.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-900 dark:bg-black text-white py-20 text-center">
         <h2 className="text-3xl font-bold mb-6">
           {t.cta}
         </h2>
         <button 
           onClick={() => onNavigate('contact')}
           className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-3 rounded-full font-bold transition-colors"
         >
           {t.btn}
         </button>
      </section>
    </div>
  );
};

export default CustomerRelations;