import React from 'react';
import { UserCheck, Calendar, Briefcase, FileText, Phone, Coffee } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface AdminSupportProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const AdminSupport: React.FC<AdminSupportProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).services.pages.admin;
  const isEn = language === 'EN';

  const features = [
    { icon: Calendar, title: isEn ? 'Calendar Management' : 'Gestión de Calendario', desc: isEn ? 'Complex scheduling across time zones to maximize your productivity.' : 'Programación compleja en diferentes zonas horarias para maximizar su productividad.' },
    { icon: Briefcase, title: isEn ? 'Travel Coordination' : 'Coordinación de Viajes', desc: isEn ? 'Seamless travel arrangements, itineraries, and logistics planning.' : 'Gestión de viajes sin problemas, itinerarios y planificación logística.' },
    { icon: FileText, title: isEn ? 'Document Prep' : 'Preparación de Documentos', desc: isEn ? 'Preparation of reports, presentations, and meeting materials.' : 'Preparación de informes, presentaciones y materiales de reuniones.' },
    { icon: Phone, title: isEn ? 'Communication Mgmt' : 'Gestión de Comunicaciones', desc: isEn ? 'Filtering emails and calls to ensure priority items reach you first.' : 'Filtrado de correos y llamadas para asegurar que los asuntos prioritarios lleguen primero.' },
    { icon: UserCheck, title: isEn ? 'Stakeholder Relations' : 'Relaciones con Interesados', desc: isEn ? 'Professional liaison with board members, partners, and clients.' : 'Enlace profesional con miembros de la junta, socios y clientes.' },
    { icon: Coffee, title: isEn ? 'Personal Assistance' : 'Asistencia Personal', desc: isEn ? 'Handling lifestyle tasks to free up more of your valuable time.' : 'Manejo de tareas de estilo de vida para liberar más de su valioso tiempo.' },
  ];

  return (
    <div className="pt-20 min-h-screen bg-white dark:bg-gray-900 transition-colors">
      {/* Hero */}
      <section className="bg-indigo-50 dark:bg-indigo-900/10 py-20 text-center transition-colors">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            {t.title}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            {t.subtitle}
          </p>
        </div>
      </section>

      {/* Main Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feat, idx) => (
                <div key={idx} className="p-8 border border-gray-100 dark:border-gray-800 rounded-xl hover:shadow-lg transition-all bg-white dark:bg-gray-800">
                   <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center mb-6">
                      <feat.icon size={24} />
                   </div>
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{feat.title}</h3>
                   <p className="text-gray-600 dark:text-gray-400">{feat.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-900 dark:bg-black text-white py-20 text-center">
         <h2 className="text-3xl font-bold mb-6">
           {t.cta}
         </h2>
         <button 
           onClick={() => onNavigate('contact')}
           className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-full font-bold transition-colors"
         >
           {t.btn}
         </button>
      </section>
    </div>
  );
};

export default AdminSupport;