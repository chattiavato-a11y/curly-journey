import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';

interface PrivacyPolicyProps {
  language: Language;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ language }) => {
  const t = translations[language].legal;
  const isEn = language === 'EN';

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="bg-white dark:bg-gray-800 py-16 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">{t.privacyTitle}</h1>
          <p className="text-gray-600 dark:text-gray-400">{t.lastUpdated}</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="bg-white dark:bg-gray-800 p-8 md:p-12 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">1. {isEn ? 'Introduction' : 'Introducción'}</h2>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
              {isEn 
                ? 'At Gabriel Professional Services ("we," "our," or "us"), we respect your privacy and are committed to protecting your personal data.'
                : 'En Gabriel Professional Services ("nosotros", "nuestro" o "nuestro"), respetamos su privacidad y nos comprometemos a proteger sus datos personales.'}
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">2. {isEn ? 'The Data We Collect' : 'Los Datos que Recopilamos'}</h2>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
              {isEn 
                ? 'We may collect, use, store and transfer different kinds of personal data about you:'
                : 'Podemos recopilar, usar, almacenar y transferir diferentes tipos de datos personales sobre usted:'}
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600 dark:text-gray-400">
              <li><strong>{isEn ? 'Identity Data' : 'Datos de Identidad'}</strong></li>
              <li><strong>{isEn ? 'Contact Data' : 'Datos de Contacto'}</strong></li>
              <li><strong>{isEn ? 'Technical Data' : 'Datos Técnicos'}</strong></li>
              <li><strong>{isEn ? 'Usage Data' : 'Datos de Uso'}</strong></li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;