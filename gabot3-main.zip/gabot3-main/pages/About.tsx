import React from 'react';
import { Target, Eye, Users, Briefcase, Award, Zap } from 'lucide-react';
import { Page, Language } from '../types';
import { motion } from 'framer-motion';
import { translations } from '../translations';

interface AboutProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const About: React.FC<AboutProps> = ({ onNavigate, language }) => {
  // Defensive fallback to EN if language or about key is missing
  const t = (translations[language] || translations['EN']).about;
  const valueIcons = [Award, Users, Briefcase, Zap];

  if (!t) return <div className="pt-20 text-center">Loading...</div>;

  return (
    <div className="pt-20 min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      {/* About Hero */}
      <section className="bg-white dark:bg-gray-800 py-16 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            {t.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-300"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12">
           <motion.div 
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700"
           >
             <div className="flex items-center gap-4 mb-6">
               <Target className="text-brand-600 dark:text-brand-400" size={32} />
               <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t.mission}</h2>
             </div>
             <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-lg">
               {t.missionText}
             </p>
           </motion.div>
           <motion.div 
             initial={{ opacity: 0, x: 20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700"
           >
             <div className="flex items-center gap-4 mb-6">
               <Eye className="text-brand-600 dark:text-brand-400" size={32} />
               <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t.vision}</h2>
             </div>
             <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-lg">
               {t.visionText}
             </p>
           </motion.div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">{t.storyTitle}</h2>
          <div className="space-y-6 text-gray-600 dark:text-gray-300 text-lg leading-relaxed">
            <p>{t.story1}</p>
            <p>{t.story2}</p>
            <p>{t.story3}</p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
           <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-16 text-center">{t.valuesTitle}</h2>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {t.values.map((val: any, idx: number) => {
                const Icon = valueIcons[idx % valueIcons.length];
                return (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="text-center p-6"
                  >
                    <div className="w-16 h-16 mx-auto bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full flex items-center justify-center mb-6 shadow-sm">
                      <Icon size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{val.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400">{val.text}</p>
                  </motion.div>
                );
              })}
           </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-24 bg-gradient-to-r from-brand-700 to-blue-600 text-white text-center relative overflow-hidden">
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <h2 className="text-4xl font-bold mb-6">{t.ctaTitle}</h2>
          <button 
            onClick={() => onNavigate('contact')}
            className="bg-white text-brand-700 hover:bg-gray-100 px-10 py-4 rounded-full font-bold text-lg shadow-xl transition-all transform hover:scale-105"
          >
            {t.ctaBtn}
          </button>
        </div>
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        </div>
      </section>
    </div>
  );
};

export default About;