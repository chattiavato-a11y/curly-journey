import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';

interface TermsOfServiceProps {
  language: Language;
}

const TermsOfService: React.FC<TermsOfServiceProps> = ({ language }) => {
  const t = translations[language].legal;
  const isEn = language === 'EN';

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="bg-white dark:bg-gray-800 py-16 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">{t.termsTitle}</h1>
          <p className="text-gray-600 dark:text-gray-400">{t.lastUpdated}</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="bg-white dark:bg-gray-800 p-8 md:p-12 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">1. {isEn ? 'Agreement to Terms' : 'Aceptación de los Términos'}</h2>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
              {isEn 
                ? 'By accessing our website, you are agreeing to be bound by these terms of service.'
                : 'Al acceder a nuestro sitio web, usted acepta estar sujeto a estos términos de servicio.'}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;