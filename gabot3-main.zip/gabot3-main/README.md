# Gabriel Professional Services

A high-fidelity corporate website for Gabriel Professional Services, featuring a React frontend with interactive 3D elements (Three.js/Fiber) and a Dart backend API.

## Project Structure

- **Frontend**: React, Tailwind CSS, Framer Motion, React Three Fiber.
- **Backend**: Dart, Shelf.

## Getting Started

### Prerequisites

- Node.js (for serving the frontend)
- Dart SDK (for running the backend)

### Running the Frontend

The frontend uses ES Modules and CDNs, so it requires a static file server to run correctly (opening `index.html` directly in the browser will not work due to CORS policies on modules).

```bash
# Install the 'serve' utility (one-time setup)
npm install

# Start the frontend
npm start
```

Visit `http://localhost:3000` in your browser.

### Running the Backend

The backend is a Dart application located in the `backend/` directory.

```bash
# Navigate to backend directory
cd backend

# Get dependencies
dart pub get

# Run the server
dart run bin/server.dart
```

The backend server will start on port 8080.

## CI/CD: Cloudflare Pages via GitHub Actions

This repo includes a GitHub Actions workflow that deploys the site to Cloudflare Pages on
pushes to `main` and creates preview deployments for pull requests. Configure these secrets
in your GitHub repository settings:

- `CLOUDFLARE_API_TOKEN`: API token with Pages edit permissions
- `CLOUDFLARE_ACCOUNT_ID`: Cloudflare account ID
- `CLOUDFLARE_PAGES_PROJECT`: Pages project name

The workflow publishes the repository root (`.`) as a static site.

## Features

- **3D Elements**: Interactive starfield hero section and 3D logo.
- **Animations**: Smooth page transitions and scroll animations using Framer Motion.
- **Responsive Design**: Fully responsive layout optimized for mobile and desktop.
- **Dark Mode**: System-aware dark mode support.
