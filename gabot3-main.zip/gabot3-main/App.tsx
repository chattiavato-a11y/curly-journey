import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Services from './pages/Services';
import About from './pages/About';
import Careers from './pages/Careers';
import Contact from './pages/Contact';
import SignIn from './pages/SignIn';
import GetStarted from './pages/GetStarted';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import GDPR from './pages/GDPR';
import Consent from './pages/Consent';
import Logistics from './pages/Logistics';
import ITSupport from './pages/ITSupport';
import AdminSupport from './pages/AdminSupport';
import CustomerRelations from './pages/CustomerRelations';
import Learning from './pages/Learning';
import Checkout from './pages/Checkout';
import { Page, Language } from './types';
import { motion, AnimatePresence } from 'framer-motion';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(() => {
    const last = localStorage.getItem('lastPage');
    return (last as Page) || 'home';
  });

  const [targetSection, setTargetSection] = useState<string | undefined>(undefined);
  const [selectedPlan, setSelectedPlan] = useState<string>('itsupport_l1');
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    if (saved === 'EN' || saved === 'ES') return saved;
    return 'EN';
  });

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const metaThemeColor = document.querySelector("meta[name=theme-color]");
    
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
      metaThemeColor?.setAttribute("content", "#111827");
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
      metaThemeColor?.setAttribute("content", "#ffffff");
    }
  }, []);

  const toggleTheme = () => {
    const metaThemeColor = document.querySelector("meta[name=theme-color]");
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
      metaThemeColor?.setAttribute("content", "#ffffff");
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
      metaThemeColor?.setAttribute("content", "#111827");
    }
  };

  const toggleLanguage = () => {
    const nextLang = language === 'EN' ? 'ES' : 'EN';
    setLanguage(nextLang);
    localStorage.setItem('language', nextLang);
  };

  const handleNavigate = (page: Page, sectionId?: string) => {
    setCurrentPage(page);
    setTargetSection(sectionId);
    localStorage.setItem('lastPage', page);
    if (!sectionId) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSetPlan = (planId: string) => {
    setSelectedPlan(planId);
  };

  const renderPage = () => {
    const props = { onNavigate: handleNavigate, language };
    
    switch (currentPage) {
      case 'home':
        return <Home {...props} />;
      case 'services':
        return <Services {...props} targetSection={targetSection} onSetPlan={handleSetPlan} />;
      case 'logistics':
        return <Logistics {...props} />;
      case 'itsupport':
        return <ITSupport {...props} />;
      case 'admin':
        return <AdminSupport {...props} />;
      case 'relations':
        return <CustomerRelations {...props} />;
      case 'about':
        return <About {...props} />;
      case 'careers':
        return <Careers {...props} />;
      case 'learning':
        return <Learning {...props} />;
      case 'contact':
        return <Contact language={language} />;
      case 'signin':
        return <SignIn {...props} />;
      case 'getstarted':
        return <GetStarted {...props} />;
      case 'checkout':
        return <Checkout {...props} initialPlan={selectedPlan} onSetPlan={handleSetPlan} />;
      case 'privacy':
        return <PrivacyPolicy language={language} />;
      case 'terms':
        return <TermsOfService language={language} />;
      case 'gdpr':
        return <GDPR language={language} />;
      case 'consent':
        return <Consent language={language} />;
      default:
        return <Home {...props} />;
    }
  };

  const isAuthPage = currentPage === 'signin' || currentPage === 'getstarted' || currentPage === 'checkout';

  return (
    <div className="flex flex-col min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      {!isAuthPage && (
        <Navbar 
          currentPage={currentPage} 
          onNavigate={handleNavigate} 
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          language={language}
          toggleLanguage={toggleLanguage}
        />
      )}
      <main className="flex-grow overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.4, ease: "anticipate" }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>
      {!isAuthPage && <Footer onNavigate={handleNavigate} language={language} />}
    </div>
  );
};

export default App;